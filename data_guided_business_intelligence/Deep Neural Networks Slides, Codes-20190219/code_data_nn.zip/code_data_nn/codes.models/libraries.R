## Checkpoint package
if (!"checkpoint" %in% rownames(installed.packages())) install.packages("checkpoint")

library(checkpoint)
checkpoint("2016-06-21", R.version = "3.3.1 ")

## Install the relavant packages
## Tools
if (!"RCurl" %in% rownames(installed.packages())) install.packages("RCurl", dependencies = TRUE)
if (!"jsonlite" %in% rownames(installed.packages())) install.packages("jsonlite", dependencies = TRUE)
if (!"caret" %in% rownames(installed.packages())) install.packages("caret", dependencies = TRUE)
if (!"e1071" %in% rownames(installed.packages())) install.packages("e1071", dependencies = TRUE)

library(RCurl)
library(jsonlite)
library(caret)
library(e1071)

## Basic stats packages
if (!"statmod" %in% rownames(installed.packages())) install.packages("statmod", dependencies = TRUE)
if (!"MASS" %in% rownames(installed.packages())) install.packages("MASS", dependencies = TRUE)

library(statmod)
library(MASS)

## Neural networks
if (!"nnet" %in% rownames(installed.packages())) install.packages("nnet", dependencies = TRUE)
if (!"neuralnet" %in% rownames(installed.packages())) install.packages("neuralnet", dependencies = TRUE)
if (!"RSNNS" %in% rownames(installed.packages())) install.packages("RSNNS", dependencies = TRUE)

library(nnet)
library(neuralnet)
library(RSNNS)

## Deep learning
if (!"deepnet" %in% rownames(installed.packages())) install.packages("deepnet", dependencies = TRUE)
if (!"darch" %in% rownames(installed.packages())) install.packages("darch", dependencies = TRUE)
if (!"h2o" %in% rownames(installed.packages())) install.packages("h2o", dependencies = TRUE)

library(deepnet)
library(darch)
library(h2o)

# Parallel Computing
#if (!"parallel" %in% rownames(installed.packages())) install.packages("parallel", dependencies = TRUE)
if (!"foreach" %in% rownames(installed.packages())) install.packages("foreach", dependencies = TRUE)
if (!"doSNOW" %in% rownames(installed.packages())) install.packages("doSNOW", dependencies = TRUE)

library(parallel)
library(foreach)
library(doSNOW)

# Parameter Search and Optimization
if (!"gridExtra" %in% rownames(installed.packages())) install.packages("gridExtra", dependencies = TRUE)

library(gridExtra)

# Lasso and Elastic-Net Regularized Generalized Linear Models
if (!"glmnet" %in% rownames(installed.packages())) install.packages("glmnet", dependencies = TRUE)

library(glmnet)

# GAMs, GAMMs and other generalized ridge regression with 
# multiple smoothing parameter estimation by GCV, REML or UBRE/AIC. 
# Includes a gam() function, a wide variety of smoothers, 
# JAGS support and distributions beyond the exponential family.
if (!"mgcv" %in% rownames(installed.packages())) install.packages("mgcv", dependencies = TRUE)

library(mgcv)

#  Extension of Data.frame. Fast aggregation of large data, 
# fast ordered joins, fast add/modify/delete of columns ...
if (!"data.table" %in% rownames(installed.packages())) install.packages("data.table", dependencies = TRUE)

library(data.table)