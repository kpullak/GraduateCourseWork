
# set working directory to the source of the file:
# Session --> Set Working Directory --> To Source File Location

source ("./libraries.R")

#------------------------------------------
# Building Neural Network Model: Digit Recognition
# R Package: nnet
# Data set:
## https://www.kaggle.com/c/digit-recognizer
#------------------------------------------

digits.train <- read.csv("../data/train.csv")
dim(digits.train)
head(colnames(digits.train), 4)
tail(colnames(digits.train), 4)
head(digits.train[, 1:4])


## convert to factor so  R knows that 
## this is a classification not a regression problem
digits.train$label <- factor(digits.train$label, levels = 0:9)

# select just the first 5,000 for these first examples for 
# building and training a neural network
# separate the data into the features or predictors (digits.X) 
# and the outcome (digits.Y). 
i <- 1:5000
digits.X <- digits.train[i, -1]
digits.y <- digits.train[i, 1]


# check the distribution of the digits:
# they are fairly evenly distributed so there is no real need 
# to increase the weight or importance given to any particular one
barplot(table(digits.y))

# build and train our first neural network using the nnet package 
# through the caret package wrapper.
set.seed(1234)
#digits.m1 <- train(digits.X, digits.y,
#                   method = "nnet",
#                   tuneGrid = expand.grid(
#                     .size = c(5),
#                     .decay = 0.1),
#                   trControl = trainControl(method = "none"),
#                   MaxNWts = 10000,
#                   maxit = 100)

#save (digits.m1, file="digits.m1.Rda")

load (file="digits.m1.Rda")
# predict using training data
digits.yhat1 <- predict(digits.m1)
barplot(table(digits.yhat1))

# use confusionMatrix() from caret package
# to compute performance
# Acccuracy: 44%
caret::confusionMatrix(xtabs(~digits.yhat1 + digits.y))

# Increasing the number of hidden neurons from 5 to 10, 
# which is one key way to improve model performance
set.seed(1234)
#digits.m2 <- train(digits.X, digits.y,
#                   method = "nnet",
#                   tuneGrid = expand.grid(
#                     .size = c(10),
#                     .decay = 0.1),
#                   trControl = trainControl(method = "none"),
#                   MaxNWts = 50000,
#                   maxit = 100)

#save (digits.m2, file="digits.m2.Rda")
load (file="digits.m2.Rda")

digits.yhat2 <- predict(digits.m2)
barplot(table(digits.yhat2))

# Accuracy: ~58%
caret::confusionMatrix(xtabs(~digits.yhat2 + digits.y))

# Increasing the number of hidden neurons from 10 to 40:
# Note we are increasing the model complexity, hence increasing
# the risk of model overfitting
set.seed(1234)
digits.m3 <- train(digits.X, digits.y,
                   method = "nnet",
                   tuneGrid = expand.grid(
                     .size = c(40),
                     .decay = 0.1),
                   trControl = trainControl(method = "none"),
                   MaxNWts = 50000,
                   maxit = 100)

save (digits.m3, file="digits.m3.Rda")
load (file="digits.m3.Rda")


digits.yhat3 <- predict(digits.m3)
barplot(table(digits.yhat3))

# Accuracy: ~81%
caret::confusionMatrix(xtabs(~digits.yhat3 + digits.y))

#-----------------------------------------
# Building Neural Network Model: Digit Recognition
# R Package: RSNNS
#  This package provides an interface to quite 
#   a variety of possible models: 
#    basic, single-hidden-layer, feed-forward neural network 
#    (using multi-layer perceptron mlp() function),
#    other types of neural network architectures to be trained, 
#    including recurrent neural networks, and also 
#    a greater variety of learning functions
# Data set:
## https://www.kaggle.com/c/digit-recognizer
#-----------------------------------------

# Note that multi-class outcomes (such as digits), 
# RSNNS requires a dummy coded matrix, 
# so each possible class is represented as a column coded as 0/1. 
# This is facilitated using the decodeClassLabels() function.
# Use the encodeClassLabels() function to convert back into 
# a single vector of digit labels to plot 
# and evaluate model performance

head(decodeClassLabels(digits.y))

set.seed(1234)
digits.m4 <- mlp(as.matrix(digits.X),
                 decodeClassLabels(digits.y),
                 size = 40,
                 learnFunc = "Rprop",
                 shufflePatterns = FALSE,
                 maxit = 60)

save (digits.m4, file="digits.m4.Rda")
load (file="digits.m4.Rda")

digits.yhat4 <- fitted.values(digits.m4)
digits.yhat4 <- encodeClassLabels(digits.yhat4)

barplot(table(digits.yhat4))
dev.off()

# Accuracy: 88%
caret::confusionMatrix(xtabs(~ I(digits.yhat4 - 1) + digits.y))


# Use the final model to predict the model
# using different strategies for deciding the class label

digits.yhat4.insample <- fitted.values(digits.m4)
head(round(digits.yhat4.insample, 2))

# Strategy #1: Winner Takes All (WTA) method, 
# is to choose the class with the highest probability 
# so long as there are no ties, 
# the highest probability is above a user-defined threshold
# (the threshold could be zero), and 
# the remaining classes all have a predicted probability 
# under the maximum minus another user-defined threshold.

table(encodeClassLabels(digits.yhat4.insample,
                        method = "WTA", l = 0, h = 0))

table(encodeClassLabels(digits.yhat4.insample,
                        method = "WTA", l = 0, h = .5))

table(encodeClassLabels(digits.yhat4.insample,
                        method = "WTA", l = .2, h = .5))

# Strategy #2: A final method, called 402040, 
# classifies if only one value is above a user-defined threshold, 
# and all other values are below another user-defined threshold; 
# if multiple values are above the first threshold, 
# or any value is not below the second threshold, 
# it treats the observation as unknown

table(encodeClassLabels(digits.yhat4.insample,
                        method = "402040", l = .4, h = .6))

# Use the final model to predict on Test data
# using the next 5,000 observations and WTA strategy

i2 <- 5001:10000
digits.yhat4.pred <- predict(digits.m4,
                             as.matrix(digits.train[i2, -1]))

table(encodeClassLabels(digits.yhat4.pred,
                        method = "WTA", l = 0, h = 0))



caret::confusionMatrix(xtabs(~digits.train[i2, 1] +
                               I(encodeClassLabels(digits.yhat4.pred) - 1)))



digits.yhat1.pred <- predict(digits.m1, digits.train[i2, -1])
digits.yhat2.pred <- predict(digits.m2, digits.train[i2, -1])
digits.yhat3.pred <- predict(digits.m3, digits.train[i2, -1])


measures <- c("AccuracyNull", "Accuracy", "AccuracyLower", "AccuracyUpper")

n5.insample <- caret::confusionMatrix(xtabs(~digits.y + digits.yhat1))
n5.outsample <- caret::confusionMatrix(xtabs(~digits.train[i2, 1] + digits.yhat1.pred))

n10.insample <- caret::confusionMatrix(xtabs(~digits.y + digits.yhat2))
n10.outsample <- caret::confusionMatrix(xtabs(~digits.train[i2, 1] + digits.yhat2.pred))

n40.insample <- caret::confusionMatrix(xtabs(~digits.y + digits.yhat3))
n40.outsample <- caret::confusionMatrix(xtabs(~digits.train[i2, 1] + digits.yhat3.pred))

n40b.insample <- caret::confusionMatrix(xtabs(~digits.y + I(digits.yhat4 - 1)))
n40b.outsample <- caret::confusionMatrix(xtabs(~digits.train[i2, 1] +
                                                 I(encodeClassLabels(digits.yhat4.pred) - 1)))


## Comparative analysis of different model results
shrinkage <- rbind(
  cbind(Size = 5, Sample = "Train", as.data.frame(t(n5.insample$overall[measures]))),
  cbind(Size = 5, Sample = "Test", as.data.frame(t(n5.outsample$overall[measures]))),
  cbind(Size = 10, Sample = "Train", as.data.frame(t(n10.insample$overall[measures]))),
  cbind(Size = 10, Sample = "Test", as.data.frame(t(n10.outsample$overall[measures]))),
  cbind(Size = 40, Sample = "Train", as.data.frame(t(n40.insample$overall[measures]))),
  cbind(Size = 40, Sample = "Test", as.data.frame(t(n40.outsample$overall[measures]))),
  cbind(Size = 40, Sample = "Train", as.data.frame(t(n40b.insample$overall[measures]))),
  cbind(Size = 40, Sample = "Test", as.data.frame(t(n40b.outsample$overall[measures])))
)
shrinkage$Pkg <- rep(c("nnet", "RSNNS"), c(6, 2))

dodge <- position_dodge(width=0.4)

p.shrinkage <- ggplot(shrinkage, aes(interaction(Size, Pkg, sep = " : "), Accuracy,
                                     ymin = AccuracyLower, ymax = AccuracyUpper,
                                     shape = Sample, linetype = Sample)) +
  geom_point(size = 2.5, position = dodge) +
  geom_errorbar(width = .25, position = dodge) +
  xlab("") + ylab("Accuracy + 95% CI") +
  theme_classic() +
  theme(legend.key.size = unit(1, "cm"), legend.position = c(.8, .2))

options (digits=2)
shrinkage

print(p.shrinkage)
